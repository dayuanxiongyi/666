<h1><p align="center">BVPN</p></h1>

## Easy to use
1. 访问官网 >>>>>> [官网](https://www.bvpn.com)
2. 在官网正上方可选网站语言
3. 在官网右上方点击“登录”
4. 在跳转的页面上点击注册
5. 在下载页面下载需要的客户端版本 >>>>>> [官网下载](https://www.bvpn.com/cn/#download)
6. 登录使用即可

## 注意
1. 目前支持免费试用
2. 支持支付宝、财付通、银联支付
3. 支持Windows系统的b.VPN OpenVPN客户端（支持Windows Vista, 7, 8, 8.1 & 10）
4. 支持Mac OS系统的b.VPN OpenVPN客户端（支持Mac OS 10.7, 10.8, 10.9, 10.10, 10.11 & 10.12）
5. 支持iOS的b.VPN L2TP VPN客户端（支持所有iOS设备iPhone，iPad，iPod）
6. 支持Android的b.VPN OpenVPN客户端（支持所有Android 4.0.3以上的设备）

## 费用
1. 每月9.9美元
2. 半年套餐，每月8.33美元，一年50美元
3. 包年套餐，每月7.5美元，一年90美元

## 下载
[BVPN FOR WINDOWS](https://github.com/carolcoral/free_vpn/releases/download/BVPN%4020190225/bVPN_2_5_1_setup.exe)



# vpn

部分免费的 VPN。亲测有效的科学上网，同时支持 windows、mac、linux、ios 和 andrioid 系统。并提供 chrome、firefox、opera 等浏览器的插件使用。

**推荐使用 [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)**

## 申明：

> 请科学上网，本人对后续所有除技术问题外秉承：不回答、不负责、不回应、不处理 态度.

> 如果多人一起使用推荐使用 Bandwagon，单人使用推荐使用 shadowsocks.

> 本repo同时还有其他vpn的相关介绍，详情可以查看 WIKI.

## [WIKI](https://github.com/carolcoral/no-free_vpn/wiki)

## [公告](https://github.com/carolcoral/no-free_vpn/wiki/%E5%85%AC%E5%91%8A)：

> `2023-03-15` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)有重大更新公告，请点击查看

> `2023-02-28` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)我们正在修复 Lite 服务无法使用的问题，在此期间请您耐心等待，无需发送服务工单。

> `2022-12-20` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks) 支付宝渠道已恢复使用

> `2022-11-10` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks) 双十一大促活动

> `2022-10-24` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks) 更新最新访问地址

> `2022-07-13` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks) 更新最新访问地址和相关可用节点

> `2021-11-10` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)为回馈新老客户，在双十一活动¹期间，访问活动页面续费或新购服务时，将享受 30% - 40% 折扣²的优惠价格。

> `2021-10-22` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)美国节点维护中，请暂时使用其他节点

> `2021-07-28` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)变更访问地址

> `2020-06-19` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)618活动，新购和续费用户使用口令‘trojan618’获得8折优惠

> `2020-05-09` —— [SS](https://carolcoral.github.io/no-free_vpn/shadowsocks)调整访问地址，新增台湾节点

> `2020-04-07` —— 因为SS正在升级服务导致服务不够稳定，目前推荐使用[Kuli](https://carolcoral.github.io/no-free_vpn/kuli)云

> `2020-03-17` —— 因为某些原因，SS的用户需要手动去官网转换节点后使用

> `2019-12-24` —— 搬瓦工1g2核1t流量已经上货，有需要的可以购买了[WIKI](https://carolcoral.github.io/no-free_vpn/Bandwagon)

> `2019-12-05` —— 新增[Vultr](https://carolcoral.github.io/no-free_vpn/vultr)服务

> `2019-12-05` —— 丰富的java工具包[CommonUtil](https://github.com/carolcoral/CommonUtil),欢迎大家start、fork、issues.

> `2019-11-01` —— 目前全部VPN节点可用

> `2019-10-11` —— 新货 KuLi云 更新，ss日本节点可用

> `2019-10-09` —— ss部分节点可用，搬瓦工目前仍然ip封禁中

> `2019-06-17` —— 经过检测，`SS`和`banwagong`目前已经可用

> `2019-06-04` —— 因为目前大陆处于敏感时间，预计将会有长达`3个月`的时间无法正常使用`vpn`，请各位知悉。目前已知`SS`和`搬瓦工`已经被封掉大量`IP`和`端口`

<h1><p align="center">KuLi云</p></h1>

## Easy to use
1. 访问官网 >>>>>> [官网](https://coyun.space/auth/register?code=C8QG)
2. 在官网右上方点击“登录”
3. 在跳转的页面上点击注册
4. 在下载页面下载需要的客户端版本
5. 登录使用即可

## 注意
1. 目前支持免费试用3 天
2. 支持支付宝、财付通、银联支付
3. 支持Windows系统的b.VPN OpenVPN客户端（支持Windows Vista, 7, 8, 8.1 & 10）
4. 支持Mac OS系统的b.VPN OpenVPN客户端（支持Mac OS 10.7, 10.8, 10.9, 10.10, 10.11 & 10.12）
5. 支持iOS的b.VPN L2TP VPN客户端（支持所有iOS设备iPhone，iPad，iPod）
6. 支持Android的b.VPN OpenVPN客户端（支持所有Android 4.0.3以上的设备）

## 费用
1. 月付最低13元
2. [详细价格表](https://coloo.site/user/shop)



<h1><p align="center">VULTR</p></h1>

## Easy to use
1. 访问官网 >>>>>> [官网](https://my.vultr.com/billing/)
2. 感谢[@akirasen](https://github.com/akirasen) 提供的使用[教程](https://fileem.com/how-can-the-shadowsocket-ladder-not-be-used-2-5-knives-a-month-try-to-build-a-ladder-with-v2ray-ten-minutes-to-build-the-most-complete-ladder-tutorial-in-history)

## 注意
1. 目前信用卡付费优惠10美元
2. 支持安卓、IOS、windows、mac等

## 费用

![](https://github.com/carolcoral/SaveImg/blob/master/vlutr.png?raw=true)
